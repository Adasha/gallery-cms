<div class="wrap">
  <h1>Art CMS Control Panel</h1>
  <p>...</p>
</div>
